---
name: Coastal Dune
colors:
  surface: '#fff8f6'
  surface-dim: '#efd4cc'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ed'
  surface-container: '#ffe9e3'
  surface-container-high: '#fee2da'
  surface-container-highest: '#f8ddd4'
  on-surface: '#261813'
  on-surface-variant: '#55433e'
  inverse-surface: '#3d2d27'
  inverse-on-surface: '#ffede8'
  outline: '#88726c'
  outline-variant: '#dbc1ba'
  surface-tint: '#97472e'
  primary: '#94452c'
  on-primary: '#ffffff'
  primary-container: '#b35c41'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59f'
  secondary: '#456558'
  on-secondary: '#ffffff'
  secondary-container: '#c7ead9'
  on-secondary-container: '#4b6b5d'
  tertiary: '#76553d'
  on-tertiary: '#ffffff'
  tertiary-container: '#926d54'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59f'
  on-primary-fixed: '#3a0a00'
  on-primary-fixed-variant: '#793019'
  secondary-fixed: '#c7ead9'
  secondary-fixed-dim: '#accebe'
  on-secondary-fixed: '#002116'
  on-secondary-fixed-variant: '#2e4d40'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#eabda0'
  on-tertiary-fixed: '#2d1604'
  on-tertiary-fixed-variant: '#5f402a'
  background: '#fff8f6'
  on-background: '#261813'
  surface-variant: '#f8ddd4'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1.25rem
  margin-tablet: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system embodies the warmth, unhurried cadence, and tactile craftsmanship of a beachside specialty espresso bar. Designed around the everyday ritual of seaside morning coffee, it blends **Warm Minimalism** with **Organic Tactility**—dispensing with cold digital sterility in favor of sun-bleached tones, sun-baked terracotta, and oceanic sage accents.

### Personality & Values
- **Warm & Unhurried:** Feels like an open window facing the Pacific at 7:30 AM—calming, welcoming, and sensory.
- **Artisanal Precision:** Grounded by deep espresso roasts and clean geometric typography, honoring the craft of specialty coffee.
- **Coastal Tactility:** Surfaces evoke linen, dry sand, smooth drift pebbles, and weathered timber through generous pillowy contours and warm ambient shadows.

### Target Audience
Locals, beachgoers, surfers, and traveling coffee enthusiasts seeking an effortless mobile ordering experience that feels like a natural extension of the physical beachside café counter rather than a generic fast-food kiosk.

## Colors

The palette balances sun-drenched coastal warmth with the rich tonality of roasted beans and sea mist:

- **Primary (`#C86D51` Terracotta Roast):** Drives primary calls to action, selected active states, and checkout triggers. Evokes sun-baked clay, coastal brick, and medium-roast crema.
- **Secondary (`#7C9D8E` Breezy Coastal Sage):** Used for positive milestones, completed order steppers, toggle confirmations, and gentle badges.
- **Tertiary (`#6F4E37` Deep Drip Espresso):** Anchor color for secondary interactive pills, drink customization highlights, and structural emphasis.
- **Neutral (`#2E1F1A` Dark Espresso Bean):** Replaces harsh pure black for high-contrast, accessible typography, icons, and defined outlines.

### Background & Surface Hierarchy
- **Canvas Base:** `#F7F4EE` (Warm Sand), an off-white hue with a yellow-linen undertone that eliminates blue-light eye strain.
- **Surface Elevation 1 (Cards, Sheet Modals):** `#FFFFFF` with warm undertones or `#EFE9DC` (Dune Mist) for soft tonal separation.
- **Accents:** `#A3C9B8` (Soft Seafoam) for quiet interactive backgrounds, inactive badge tints, and subtle track fills.

## Typography

The design system exclusively leverages **Plus Jakarta Sans** for headlines, editorial welcomes, body text, and UI labels. Its geometric circular chassis combined with subtle humanistic curves gives mobile coffee ordering a breezy, modern, yet warmly approachable character.

### Application Rules
- **Display & Headlines:** Used for personal customer salutations (`Welcome, Sidd`), featured roasts (`Today's Special`), and checkout order totals. Bold weights should retain tight negative tracking (`-0.02em` to `-0.01em`) to maintain editorial punch.
- **Labels & Customizer Attributes:** Attribute titles (`Size`, `Sugar`, `Cream`, `Extras`) use `title-md` or `label-lg` in medium or semibold weights to create clear visual scannability during rapid ordering.
- **Price Figures:** Digits must align vertically using proportional figures with consistent tracking matching title weights.

## Layout & Spacing

The layout is built on a mobile-first, 4-column fluid layout with an 8pt baseline rhythm, scaling to 8 columns on tablet. 

### Rhythm & Breakpoints
- **Mobile (<600px):** 4 fluid columns, `1.25rem` screen margin, `1rem` column gutter. Vertical components (product cards, cart rows, status steppers) use `1rem` stacked spacing.
- **Tablet (600px - 1024px):** 8 columns, `2rem` screen margin, centered reading container maxing out at `560px` for ordering flows to prevent wide tap targets.

### Spacing Density
- **Component Padding:** Standard cards and sheets employ `space-lg` (`1.5rem`) internal padding to sustain a breathable, resort-like feel.
- **Micro-Gaps:** Compact customization button clusters (such as `Y / N` toggles or `S / M / L / XL` chips) use `space-sm` (`0.5rem`) gaps for comfortable one-handed thumb interaction without accidental triggers.

## Elevation & Depth

This system avoids cold drop shadows and stark grey elevation tiers. Instead, depth is achieved through **ambient warm diffusion** paired with **tonal surface nesting**.

### Ambient Warm Shadows
- **Base Cards & Hero Pods:** `box-shadow: 0 8px 24px -4px rgba(46, 31, 26, 0.06), 0 2px 6px -1px rgba(46, 31, 26, 0.04)`.
- **Floating Floating CTAs & Bottom Sticky Bars:** `box-shadow: 0 12px 32px -6px rgba(200, 109, 81, 0.22), 0 4px 12px -2px rgba(46, 31, 26, 0.08)`.
- **Tonal Inset Surfaces:** Selected toggle chips and quantity steppers utilize subtle inner shadows (`inset 0 1px 3px rgba(46, 31, 26, 0.08)`) to convey physical tactile depression.

### Border Strokes
When outlines are necessary (such as unselected customization options or segmented navigation pills), use low-contrast borders: `1px solid rgba(46, 31, 26, 0.12)`. Avoid hard 100% black outlines.

## Shapes

The interface embraces organic, pillowy softness (`roundedness: 3`). Inspired by sea-softened beach stones and handcrafted ceramic mugs, interactive components feature full pill radiuses while container cards use generous `2rem` to `3rem` curves.

- **Pills (`rounded-full`):** Category segment pills (`Home`, `Menu`, `Previous Orders`, `Rewards`), location pills, option buttons (`Y/N`, size selectors), and primary CTA buttons.
- **Cards & Bottom Sheets (`rounded-3xl` / 2rem):** Product showcase cards (`Today's Special`), cart items, checkout cards, and live order tracking cards.
- **Touch Elements:** Quantity counters and circular radio checks maintain a 1:1 aspect ratio with full circular boundaries (`50%`).

## Components

### 1. Navigation & Category Segment Control
- **Segmented Bar:** Encased in a soft sand container (`#EFE9DC`) with `0.5rem` internal padding and full pill radius.
- **Active Tab:** White background (`#FFFFFF`) with warm espresso text (`#2E1F1A`), bolstered by an ambient warm shadow. Inactive tabs carry soft muted espresso (`#6F4E37`) text with no shadow.

### 2. Buttons & CTAs
- **Primary Action (e.g., "Checkout →", "Add to Cart"):** Full-width or right-aligned pill, Terracotta `#C86D51` background, cream `#F7F4EE` bold typography. Height is minimum 52px for thumb-friendly mobile operation.
- **Secondary / Ghost Actions (e.g., "+ More Items"):** Cream sand background (`#EFE9DC`) with a `1.5px` border in `#2E1F1A` at 15% opacity, Dark Espresso typography, and full pill rounding.

### 3. Selection Chips & Toggles
- **Customization Options (`Sugar: Y / N`, `Cream: Y / N`):** Paired inline circles or micro-pills. Selected state transitions to Terracotta `#C86D51` with white bold text; unselected sits in clean white `#FFFFFF` with a subtle espresso border.
- **Size Selector (`S | M | L | XL`):** Segmented pill row. The active size (e.g., `M`) is framed by a filled Terracotta ring or solid Terracotta circle with high-contrast inverted white text.

### 4. Cards & Product Displays
- **Featured Roast Hero (`Today's Special`):** Deep pillowy white card (`#FFFFFF`) sitting on the warm sand canvas (`#F7F4EE`). Contains a generous illustrated/photographic cup zone, centered title in `headline-md`, and subtle seafoam or sage decorative badges.
- **Cart Summary Row:** Clean bordered list entry with cup thumbnail on the left, name and price on the right, and an integrated `+ 1 -` stepper with tactile circular tap targets.

### 5. Payment Selection List
- **List Items:** Horizontal card rows with `1.25rem` padding, featuring custom radio indicators. Selected payment method shows a solid Sage `#7C9D8E` or Terracotta `#C86D51` checked circle. Inactive items use a ghost circular outline.

### 6. Vertical Order Status Stepper
- **Layout:** Vertical timeline with connected dotted or solid stem lines.
- **Step Nodes:**
  - **Completed (`Received`):** Solid Sage `#7C9D8E` circle containing a crisp white checkmark icon.
  - **In Progress (`Preparing`):** Pulsing dual-ring or filled Terracotta `#C86D51` circle with brewing/clock glyph.
  - **Pending (`Ready!`):** Outlined circle in warm neutral `#EFE9DC` with muted text.
- **Connecting Line:** 2px thick dashed line tinted with Sage for finished paths, and muted Sand (`#EFE9DC`) for future paths.